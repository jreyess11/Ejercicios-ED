public class Main {
    public static void main(String[] args) {

        Lista lista = new Lista();

        for (int i=0; i<5; i++){
            lista.agregar(i);
        }

        lista.imprimir();
    }
}
