public class NodoCS {
    public Object info;
    public NodoCS siguiente;

    public NodoCS(Object info) {
        this.info = info;
        this.siguiente=null;
    }
}
